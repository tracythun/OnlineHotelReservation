<?php 
session_start();
include('db.php'); 
include('Shopping_Cart_Function.php');
include('AutoID_Helper.php');

function ClearAll()
{
	unset($_SESSION['ShoppingCart_Function']);
	echo "<script>window.location='Confirm.php'</script>";
}

function Remove($id)
{
	$index=IndexOf($id);
	unset($_SESSION['ShoppingCart_Function'][$index]);
	echo "<script>window.location='Confirm.php'</script>";
}

if(!isset($_SESSION["CustomerID"]))
{
		echo "<script>window.alert('Please Login')</script>";
		echo "<script>window.location='customerlogin.php'</script>";
}

else
{
	$CustomerID=$_SESSION["CustomerID"];

	if(isset($_GET["reservation"]))
	{
		$reservation=$_GET['reservation'];

		 $sel="SELECT * from reservation
		      Where reservation_id='$reservation'";

		$ret=mysql_query($sel);
		$arr=mysql_fetch_array($ret);

		echo $fee=$arr['Fee'];
	}
	else
	{
		$reservation='';
	}	
}


if(isset($_GET['action'])) 
{
  $action=$_GET['action'];

  if($action==="Remove") 
  {
    $id=$_GET['id'];
    Remove($id);
  }
  elseif($action==="Clear") 
  {
    ClearAll();
  }
}

if(isset($_POST['btnBook'])) 
{
	$txtreservation_id=$_POST['txtreservation_id'];
	$txtcheckin=$_POST['txtcheckin'];
	$txtcheckout=$_POST['txtcheckout'];
	$txtCustomerID=$_POST['txtCustomerID'];
	$txtcontact=$_POST['txtcontact'];

	$TotalAmount=CalculateTotalAmount();
	$TotalQuantity=CalculateTotalQuantity();
	
	$Status="Pending";

	$checkreservation="SELECT * FROM reservation
			 	Where CustomerID='$txtCustomerID'";
	$result=mysql_query($checkreservation);

	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('You cannot book yet.')</script>";
		echo "<script>window.location='Confirm.php'</script>";
		exit();
	}

	$query="INSERT INTO `reservation`
			(`reservation_id`, `CustomerID`, `checkin`,`checkout`,`TotalAmount`, `TotalQuantity`,`contact`,`Status`) 
			VALUES
			('txtreservation_id','$CustomerID','$txtcheckin','$txtcheckout','$TotalAmount','$TotalQuantity','$txtcontact','$Status')";
	$result=mysql_query($query);

	//OrderDetail Save======================================================

	$count=count($_SESSION['ShoppingCart_Function']);
	for($i=0; $i < $count; $i++) 
	{ 
		$id=$_SESSION['ShoppingCart_Function'][$i]['id'];
		$price=$_SESSION['ShoppingCart_Function'][$i]['price'];
		$quantity=$_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'];

		$query_Detail="INSERT INTO `reservationdetail`
					   (`CustomerID`,`id`, `price`, `quantity`) 
						VALUES 
					   ('$CustomerID','$id','$price','$quantity')";
		$result=mysql_query($query_Detail);
	}
	//=======================================================================

	if($result) 
	{
			echo "<script>window.alert('Booking Successful!')</script>";
			echo "<script>window.location='index.php'</script>";
	}
	else
	{
			echo "<p>Something wrong in Booking" . mysql_error() . "</p>";
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>
<style>
strong
{
	margin-left: 700px;
}	

h1
{
	margin-left: 700px;
}

input[name="btnDetail"]
{
	background:#338AFF ;
	width: 60px;
	height: 30px;
	color: white;
	border-radius: 20px;
}
</style>

<body>
<div id="wrapper">
	<div id="header">
    <a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="TRACY HOTEL" /></a>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li><a href="Bookinglist.php">My Booking</a></li>
			<li><a href="dining.php">Dining</a></li>
			<li><a href="facilities.php">Facilities</a></li>
			<li><a href="rooms.php">Rooms</a></li>
			<li><a href="conference.php">Conference</a></li>
			<li><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<ul class="portfolio-area">
				<br>
				<h1 style="margin-left:320px;">Rooms</h1>
				<br><br>
		        <c>These are the rooms that are available at Tracy Hotel for accommodation.</c>
		        <p>
		 		<br>
		        <div>
		        <div class="home-portfolio-text">
				<h2 class="post-title-portfolio"></a></h2>
			  
<form action="Confirm.php" method="post">
<fieldset>
<legend>Enter Checkout Info:</legend>

<table>
<tr>
	<td>Reservation ID</td>
	<td>
	<input type="text" name="txtreservation_id" value="<?php echo AutoID('reservation','reservation_id','R-00000',6)?>">
	</td>
</tr>

<tr>
	<td>Check-in</td>
	<td>
	<input type="date" name="txtcheckin">
	</td>
</tr>

<tr>
	<td>Check-out</td>
	<td>
	<input type="date" name="txtcheckout">
	</td>
</tr>

<tr>
	<td>Customer ID</td>
	<td>
	<input type="text" name="txtCustomerID" value="<?php echo $CustomerID?>" required/>
	</td>
</tr>
<tr>
	<td>Total Amount</td>
	<td>
	<input type="text" value="$<?php echo CalculateTotalAmount() ?>" readonly/> 
	</td>
</tr>
<tr>
	<td>Total Quantity</td>
	<td>
	<input type="text" value="<?php echo CalculateTotalQuantity() ?>" readonly/>
	</td>
</tr>

<tr>
	<td>Phone Number</td>
	<td><input type="text" name="txtcontact" required/></td>
</tr>

<tr>
	<td><input type="submit" name="btnBook" value="Book"/></td>
</tr>
</table>
</fieldset>
<br><br>
<fieldset>
<legend>Booking Details:</legend>
<table cellpadding="8px">
<tr>
	<th>Image</th>
	<th>Room Type</th>
	<th>Description</th>
	<th>Price</th>
	<th>Quantity</th>
	<th>Sub-Total</th>
	<th>Actions</th>
</tr>

<?php  
$count=count($_SESSION['ShoppingCart_Function']);

for($i=0;$i<$count;$i++) 
{ 
	$id=$_SESSION['ShoppingCart_Function'][$i]['id'];
	$img=$_SESSION['ShoppingCart_Function'][$i]['img'];

	echo "<tr>";
	echo "<td><img src='$img' width='100' height='100'/></td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['name'] ."</td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['description'] ."</td>";

	echo "<td>$" . $_SESSION['ShoppingCart_Function'][$i]['price'] ."</td>";
	echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] ." pcs</td>";

	echo "<td>$" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] * $_SESSION['ShoppingCart_Function'][$i]['price'] ." </td>";
    
    echo "<td><a href='Confirm.php?action=Remove&id=$id'>Remove</a></td>";
	echo "</tr>";
}
?>
</table>

<div class="column-clear"></div>
		     	</div>
            </ul>
			<div class="clearfix"></div>
        </div>
    </div>
 
<div id="footer">
	<h4>16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM &nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
	<img src="images/logo.png" alt="TRACY HOTEL"/></a>
	<p>&copy; Copyright 2019  Tracy Hotel and Restaurant| All Rights Reserved <br /></p>
</div>
</div>
</body>
</html>
