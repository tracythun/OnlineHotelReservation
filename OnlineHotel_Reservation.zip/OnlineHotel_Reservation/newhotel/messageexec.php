<?php
	include('db.php');
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$email = $_POST['email'];	
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	mysql_query("INSERT INTO message (firstname, lastname, email, subject, message) VALUES ('$firstname', '$lastname', '$email','$subject','$message')");

header("location: sending.php");
?>