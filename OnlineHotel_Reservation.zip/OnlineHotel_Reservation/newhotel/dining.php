<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="js/sagallery.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="James Buchanan Pub and Restaurant" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
      <li><a href="Bookinglist.php">My Booking</a></li>
			<li class="current"><a href="dining.php">Dining</a></li>
			<li><a href="facilities.php">Facilities</a></li>
			<li><a href="rooms.php">Rooms</a></li>
			<li><a href="conference.php">Conference</a></li>
      <li><a href="contact.php">Contact Us</a></li>

    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<ul class="portfolio-area">	
					<br>
 					<h1 style="margin-left:350px;">Dining</h1>
 					<br><br>When you choose to stay at TRACY HOTEL, you are also choosing to sample some of the finest cuisine Yangon has to offer. Offering a complete range of premium dining options, our remarkable lake-view restaurants are complemented by a number of stylish bars and bakery. Each restaurant serves gourmet cuisine at the highest level, planned and prepared by top international chefs. Our elegant Japanese and Chinese restaurants serve contemporary reimaginings of classic dishes, offering unparalleled fine-dining experiences. La Vie En Rose, TRACY’s European dining restaurant, caters for our guests’ culinary wish, with a buffet offering over 180 European dishes freshly cooked on site each day.
 					
 					<br>
               		<li class="portfolio-item2" data-id="id-0" data-type="cat-item-4">	
			        <div>
                    <span class="image-block">
					<a class="image-zoom" href="images/big/pic1.jpg" rel="prettyPhoto[gallery]" title="La Vie En Rose"><img width="225" height="140" src="images/thumbs/pic1.jpg" alt="La Vie En Rose" title="La Vie En Rose" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
                   	Restaurant
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Wall-E">La Vie En Rose</a></h2>
                    <p class="post-subtitle-portfolio">Type: European Restaurant</p>
                    Location 12F
					</div>
                    
					</div>	
                    </li>			
				            
			                        		
               		<li class="portfolio-item2" data-id="id-1" data-type="cat-item-2">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic2.jpg" rel="prettyPhoto[gallery]" title="Voileta"><img width="225" height="140"src="images/thumbs/p2.jpg" alt="Voileta" title="Voileta"/>                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
                   	Restaurant
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Voileta">Voileta</a></h2>
                    <p class="post-subtitle-portfolio">Type: Chinese Restaurant</p>
                    Location B2
					</div>
					</div>	
                    </li>				
				       		
               		<li class="portfolio-item2" data-id="id-2" data-type="cat-item-1">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic3.jpg" rel="prettyPhoto[gallery]" title="Tokyotza"><img width="225" height="140" src="images/thumbs/p3.jpg" alt="Tokyotza" title="Tokyotza" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
                   	Restaurant
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Tokyotza">Tokyotza</a></h2>
                    <p class="post-subtitle-portfolio">Type: Japanese Restaurant</p>
                    Location 6F
					</div>
                       	
               		<li class="portfolio-item2" data-id="id-3" data-type="cat-item-4">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic4.jpg" rel="prettyPhoto[gallery]" title="Dulcet"><img width="225" height="140" src="images/thumbs/p4.jpg" alt="Dulcet" title="Dulcet" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
                   	Bakery
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Dulcet">Dulcet</a></h2>
                    <p class="post-subtitle-portfolio">Type:Bakery</p>
                    Location Ground Floor
					</div>                    
					</div>	
                    </li>			
				                              		
               		<li class="portfolio-item2" data-id="id-4" data-type="cat-item-3">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic5.jpg" rel="prettyPhoto[gallery]" title="Hotelier Rooftop Bar"><img width="225"height="140" src="images/thumbs/p5.jpg" alt="Hotelier Rooftop Bar" title="Hotelier Rooftop Bar" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Hotelier Rooftop Bar">Hotelier Rooftop Bar</a></h2>
                    <p class="post-subtitle-portfolio">Type: Bar & BBQ</p>
                    Location 15F
					</div>
                    </div>	
                    </li>			
				            
			     		              		
               		<li class="portfolio-item2" data-id="id-5" data-type="cat-item-2">	
			        <div>
                   <span class="image-block">
					<a class="image-zoom" href="images/big/pic6.jpg" rel="prettyPhoto[gallery]" title="BaliPool"><img width="225" height="140" src="images/thumbs/p6.jpg" alt="BaliPool" title="BaliPool" />                    
                    </a>
                    </span>
                   <div class="home-portfolio-text">
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="BaliPool">Bali Pool</a></h2>
                    <p class="post-subtitle-portfolio">Type: Poolside Bar</p>
                    Location Outdoor
					</div>
                    </div>	
                    </li>			
			  	             				            
			        <div class="column-clear"></div>
            		</ul>
			<div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer">
	<h4>16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM&nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
	<img src="images/logo.png" alt="TRACY HOTEL"/></a>
	<p>&copy;  Copyright 2019 Tracy Hotel and Restaurant| All Rights Reserved<br/></p>
</div>
</div>
</body>
</html>