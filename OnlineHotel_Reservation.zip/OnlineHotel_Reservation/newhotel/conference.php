<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
</head>
<style>
#submit-button    
{
  background: brown;
  color: white;  
  width: 780px; 
}

#contactright
{
  margin-left: 340px;
}

#container
{
    width: 325px;
    height: 80px;
    margin-left: 45px;
    background: #E0DFDA;
    color:black;
    border: 1px solid grey;
    border-radius: 2px;
}
</style>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="TRACY HOTEL" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
            <li><a href="Bookinglist.php">My Booking</a></li>
			<li><a href="dining.php">Dining</a></li>
			<li><a href="facilities.php">Facilities</a></li>
			<li><a href="rooms.php">Rooms</a></li>
            <li class="current"><a href="conference.php">Conference</a></li>
			<li><a href="contact.php">Contact Us</a></li>
        </ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<div class="portfolio-area" style=" padding:40px 0 20px 0;">	
				<div id="contactright">
					<h2><b>CONFERENCE</b></h2>
                    <br>
                </div>
                    <p><h1>Golden Ballroom</h1>
                    <br><h3>Location Ground Floor</h3>
                    <br><img src="images/big/ballroom.jpg">
                    The Golden Ballroom is our premier venue - suitable for hosting up to 1,000 people, it is without doubt one of Yangon’s finest function venues. It is designed specifically for large-scale events such as an international conferences and luxury wedding receptions - is furnished with a separate VIP room and fitted with high-end lighting arrangements, audio systems, and LCD projectors. This modern, contemporary function hall is the ideal venue for a range of VIP events or state visits.
				<br><br><br>

                    <p><h1>Crystal Ballroom</h1><br>
                        <h3>Location 1F </h3>
                    <img src="images/big/Glitter Ballroom.jpg">
                Our second largest function hall, The Crystal Ballroom is a stunning, functional space which may be divided into three sections, allowing guests to customise the venue to suit their exact demands and specifications.
                </div>
                <br>

            <div id="container">
            <legend><h3><b><u>Inquiry</u></h3></legend>
            <br/>          
                <b>TEL</b> +95964246022 | +959250147860
                <br/>
                Consultation Time: 09:00-20:00
            </div>
            </form>
            <br>
            <div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer" style="margin-left: 50px">
    <h4>16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
    <p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM&nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
    <img src="images/logo.png" alt="TRACY HOTEL"/></a>
    <p>&copy;  Copyright 2019 Tracy Hotel and Restaurant| All Rights Reserved<br/></p>
</div>
</div>
</body>
</html>
