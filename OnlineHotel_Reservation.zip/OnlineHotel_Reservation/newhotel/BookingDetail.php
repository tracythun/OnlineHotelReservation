<?php
session_start();
include ('db.php'); 
$id=$_GET['id'];

$query="SELECT * FROM internet_shop WHERE id='$id'";
$result=mysql_query($query);
$arr=mysql_fetch_array($result);
$name=$arr['name'];
$price=$arr['price'];
$description=$arr['description'];
$quantity=$arr['quantity'];

$img=$arr['img'];
list($width,$height)=getimagesize($img);
$w=$width/3.5;
$h=$height/3.5;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>
<style type>
input[name="btnBook"]
{
  background:#338AFF;
  color:white;
  width: 40px;
  height: 20px;
  border-color: grey;
}  
</style>

<title>Book Detail:</title>
</head>
</html>
<body>
<div id="wrapper">
  <div id="header">
    <a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="TRACY HOTEL" /></a>
      <ul id="mainnav">
      <li><a href="index.php">Home</a></li>
      <li><a href="dining.php">Dining</a></li>
      <li><a href="facilities.php">Facilities</a></li>
      <li><a href="rooms.php">Rooms</a></li>
      <li><a href="conference.php">Conference</a></li>
      <li><a href="contact.php">Contact Us</a></li>
      </ul>
  </div>

  <div id="content">
    <div id="gallerycontainer">
     <ul class="portfolio-area">
      <br>
        <h1 style="margin-left:320px;">Rooms</h1><br><br>
        <div class="home-portfolio-text">
        <h2 class="post-title-portfolio"></h2>
        <form action="Bookinglist.php" method="get">
        <input type="hidden" name="id" value="<?php echo $id ?>"/>
        <input type="hidden" name="action" value="Add"/>

        <table align="left">
            <tr>
            <td>
              <img src="<?php echo $img ?>" width="300" height="150"/>
            </td>
            <td>
              <table cellspacing="3px" style="margin-left: 50px">
            <tr>
              <td>Type:</td>
               <td><?php echo $name?></td>
            </tr>
            <tr>
              <td>Price:</td>
              <td>$<?php echo $price?></td>
            </tr>
            <tr>
              <td>Description:</td>
              <td><?php echo $description?></td>
            </tr>
            <tr>
              <td>Quantity:</td>
              <td><?php echo $quantity?> rooms left</td>
            <tr>
              <td></td>
              <td>
                No. of rooms: <input type="number" name="txtBuyQty" value="1" min="1"/>
                 <input type="submit" name="btnBook" value="Book"/>
               </td>
            </tr>
            </table>
            </td>
          </tr>
      </table>
      </form>
      <div class="column-clear"></div>
          </div>
         </div>
      </ul>
  </div>
  </div>
</div>

    
<div id="footer">
  <h4 style="margin-left: 50px">16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
  <p style="margin-left: 80px">Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM &nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
  <img src="images/logo.png" alt="TRACY HOTEL"/></a>
  <p>&copy; Copyright 2019  Tracy Hotel and Restaurant| All Rights Reserved <br /></p>
</div>

</div>
</body>
</html>
