<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="js/sagallery.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>
<style>
c
{
  margin-left: 150px;
}


</style>
<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="TRACY HOTEL" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
      <li><a href="Bookinglist.php">My Booking</a></li>
			<li><a href="dining.php">Dining</a></li>
			<li class="current"><a href="facilities.php">Facilities</a></li>
			<li><a href="rooms.php">Rooms</a></li>
      <li><a href="conference.php">Conference</a></li>
			<li><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<ul class="portfolio-area">	
					<br>
 					<h1 style="margin-left:350px;">Facilities</h1>
 					<br><br>
          <c>Tracy Hotel has set the gold standard in providing the finest facilities in Yangon. We offers you a comprehensive range of cutting edge business, fitness, and relaxation suites.</c>
          <p>
 					<br>
          <div>
          <e><img src="images/big/pic7.jpg" rel="prettyPhoto[gallery]" title="pool" width="750" height="370"></e>
          <div class="home-portfolio-text">
					<h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="pool">Swimming Pool</a></h2>
          <p class="post-subtitle-portfolio">Type:Water Sports</p>
          Location Outdoors
          <br><p>
          Our swimming pool  with a fancy bar is located on the west side of the hotel, which provide a haven of rest and entertainment for customers. 
          The perfect vantage point from which to bathe in Yangon’s sunshine, our infinity pool complex is designed to provide unrivalled relaxation in the heart of the city. 
          </div>                   
					</div>	
          </e> 
          <br>

          <div>
					<e>
          <img src="images/big/pic8.jpg" rel="prettyPhoto[gallery]" title="gym" width="750" height="370">
          </e>
          <div class="home-portfolio-text">
          <h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Gym">Gym</a></h2>
          <p class="post-subtitle-portfolio">Type: Fitness Gym</p>
          Location 1F
          <br><p>
          Our gym provides facilities with modern exercising equipment and air conditioned room in which you can view the picturesque view of the lake while staying fit at the hotel.    
			</div>
			</div>	
      <br>

      <div>
          <e>
          <img src="images/big/pic9.jpg" rel="prettyPhoto[gallery]" title="Spa" width="750" height="370">
          </e>
          <div class="home-portfolio-text">
          <h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Spa">Spa</a></h2>
          <p class="post-subtitle-portfolio">Type:Luxury Spa</p>
          Location 4F
          <br><p>
          The luxurious spa situated on the fourth floor of our hotel is the best place for releasing stress while accommodating. Professional therapists occupied at the spa will be in charge of massaging and foot reflexology. Prices range according to the part of the body you would like to get massage (for instance face, whole body or foot massage) as well as the massage type (i.e. oil massage, Thai massage, reflexology, chair massage).
      </div>
      </div>  	
			<br>

    <div>
          <e>
          <img src="images/big/pic10.jpg" rel="prettyPhoto[gallery]" title="Spa" width="750" height="370">
          </e>
          <div class="home-portfolio-text">
          <h2 class="post-title-portfolio"><a href="#" rel="bookmark" title="Spa">Meeting Room</a></h2>
          <p class="post-subtitle-portfolio">Type: Meeting Room</p>
          Location 3F
          <br><p>
          Conveniently located on the third floor of the hotel, our meeting rooms have everything you need to guarantee a memorable and successful meeting.

          Our meeting rooms are geared towards serving every need of our valued business guests. They are equipped with the most up-to-date facilities, including a PC suite, projection screen and beam projector, scanner, photo-copier, and fax machine.
    </div>
    </div>           	  
    <div class="column-clear"></div>
    </ul>
		<div class="clearfix"></div>
    </div>
    </div>
    
<div id="footer">
	<h4>16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM&nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
	<img src="images/logo.png" alt="TRACY HOTEL"/></a>
	<p>&copy;  Copyright 2019 Tracy Hotel and Restaurant| All Rights Reserved<br/></p>
</div>
</div>
</body>
</html>