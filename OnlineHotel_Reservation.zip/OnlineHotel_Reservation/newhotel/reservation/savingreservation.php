<meta http-equiv="refresh" content="5; url=../index.php">

<div style="margin:0 auto; text-align:center;">
Saving Reservation
<br>
Your Confirmaton number is
<?php
echo $_GET['confirmation'];
?><br>
<img src="ajax-loader.gif">
<br>
Pls........ wait
</div>