<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:blue;
height: 34px;
color:white;
}

</style>
<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = mysql_query("SELECT * FROM internet_shop where id='$id'");
	while($row = mysql_fetch_array($result))
			{
				$type=$row['name'];
				$rate=$row['price'];
				$rnum=$row['room_number'];
				$image=$row['img'];
			}
?>
<form action="execeditroom.php" method="post">
  <form action="editpicexec.php" method="post" enctype="multipart/form-data">
	<input type="hidden" name="roomid" value="<?php echo $id=$_GET['id'] ?>">
	Room Type:<br><input type="text" name="type" value="<?php echo $type ?>" class="ed"><br>
	Price:<br><input type="text" name="rate" value="<?php echo $rate ?>" class="ed"><br>
	Room Number:<br><input type="text" name="rnumber" value="<?php echo $rnum ?>" class="ed"><br>
	Select Image:
	<br>
	<input type="file" name="image"><br><p>
	<input type="submit" value="Edit" id="button1">
</form>
</form>



