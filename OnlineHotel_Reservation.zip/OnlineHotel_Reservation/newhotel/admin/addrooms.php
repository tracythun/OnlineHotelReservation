<script type="text/javascript">
function validateForm()
{
var a=document.forms["addroom"]["type"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter the room type");
  return false;
  }
var b=document.forms["addroom"]["price"].value;
if (b==null || b=="")
  {
  alert("Pls. Enter the room price");
  return false;
  }
var c=document.forms["addroom"]["rnum"].value;
if (c==null || c=="")
  {
  alert("Pls. enter the room number");
  return false;
  }
var c=document.forms["addroom"]["description"].value;
if (c==null || c=="")
  {
  alert("Pls. enter the room description");
  return false;
  }
var c=document.forms["addroom"]["quantity"].value;
if (c==null || c=="")
  {
  alert("Pls. enter the quantity");
  return false;
  }
var e=document.forms["addroom"]["image"].value;
if (e==null || e=="")
  {
  alert("Pls. browse an image");
  return false;
  }
/*if (c.which!=8 && c.which!=0 && (c.which<48 || c.which>57))
  {
  alert("The input U enter in Quantity field is not valid, only numbers are accepted (ex. 1, 2, 3, 4.......)");
  return false;
  }
if (b.which!=8 && b.which!=0 && (b.which<48 || b.which>57))
  {
  alert("The input U enter in Quantity field is not valid, only numbers are accepted (ex. 1, 2, 3, 4.......)");
  return false;
  }*/
}
</script>

<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:blue;
height: 34px;
color:white;
}
</style>
<!--sa input that accept number only-->
<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>

<form action="addexec.php" method="post" enctype="multipart/form-data" name="addroom" onsubmit="return validateForm()">
 Room Type<br />
  <input name="type" type="text" class="ed" /><br />
 Price<br/>
    <input name="rate" type="text" id="rate" class="ed" onkeypress="return isNumberKey(event)" /><br />
 Room Number<br/>
 <input name="rnum" type="text" id="qty" class="ed" onkeypress="return isNumberKey(event)" /><br />
 Image <br /><input type="file" name="image" class="ed"><br />
 Description<br/><input name="description" type="text" class="ed"/><br/>
 Quantity <br/><input name="quantity" type="number" min="0" class="ed" onkeypress="return isNumberKey(event"/><br/>
 <input type="submit" name="Submit" value="Save" id="button1" />
 </form>
