<?php 
     include ('db.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="js/sagallery.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="James Buchanan Pub and Restaurant" /></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
			<li><a href="dining.php">Dining</a></li>
			<li><a href="facilities.php">Facilities</a></li>
			<li><a href="rooms.php">Rooms</a></li>
			<li><a href="conference.php">Conference</a></li>
      <li><a href="contact.php">Contact Us</a></li>

    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<ul class="portfolio-area">	
					<br>
 					<h1 style="margin-left:350px;">Booking</h1>
 					<br><br>Please choose the rooms you would like to choose.

        <table cellspacing="20px">
            <?php
            $query1="SELECT * FROM internet_shop";
            $result1=mysql_query($query1);
            $count1=mysql_num_rows($result1);

            for($a=0;$a<$count1;$a+=2)    
            {
               $query2="SELECT * FROM internet_shop
                        LIMIT $a,2";
                $result2=mysql_query($query2);
                $count2=mysql_num_rows($result2);

                echo "<tr>";
                  for ($b=0;$b<$count2;$b++) 
                  { 
                      $array=mysql_fetch_array($result1);
                      $id=$array['id'];
            ?>  
            <td><img src="<?php echo $array['img'] ?>" width="200" height="200"/></td>
            <td><b style="margin-left: 20px"><?php echo $array['name'] ?></b><p>
            <b style="margin-left: 20px">$ <?php echo $array['price'] ?></b><br>
            <a href="BookingDetail.php?id=<?php echo $id?>"><input type="button" name="btnDetail" value="Detail" style="margin-left: 20px"></a></td>
            

            <?php
             }
             echo "</tr>";
            }
            ?>
         </table>
                	             				            
			        <div class="column-clear"></div>
            		</ul>
			<div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer">
	<h4>16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM&nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
	<img src="images/logo.png" alt="TRACY HOTEL"/></a>
	<p>&copy;  Copyright 2019 Tracy Hotel and Restaurant| All Rights Reserved<br/></p>
</div>
</div>
</body>
</html>