<?php
session_start();
if(isset($_SESSION['CustomerID']))
{
	session_unset($_SESSION['CustomerID']);
}
elseif (isset($_SESSION['user_id'])) 
{
	session_unset($_SESSION['user_id']);
}
else
{
	session_destroy();

}
echo "<script>
	alert('Session Expired. Login again');
	location.assign('customerlogin.php');
</script>";
?>
