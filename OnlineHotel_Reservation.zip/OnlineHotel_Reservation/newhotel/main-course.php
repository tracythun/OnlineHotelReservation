<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="js/sagallery.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>
<style>
#gallerycontainer
{
	background: #395240;
}
h1
{
	color:white;
}

</style>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="TRACY HOTEL" /></a></h1>
        <ul id="mainnav">
			<li class="current"><a href="index.php">Home</a></li>
			<li><a href="dining.php">Dining</a></li>
			<li><a href="facilities.php">Facilities</a></li>
			<li><a href="rooms.php">Rooms</a></li>
      <li><a href="conference.php">Conference</a></li>
			<li><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="gallerycontainer">
			<ul class="portfolio-area">
			<br>
			<h1 style="margin-left: 300px">Weekly Specials</h1><br><br>
			<div align="center"><img src="admin/img/weekly specials.jpg"></div><br><p>	
	    </div>           	  
    </div>    
<div id="footer">
	<h4>16 &bull; <a href="contact-us.php">U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM&nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
	<a href="index.php"><img src="images/logo.png" alt="TRACY HOTEL"/></a>
	<p>&copy;  Copyright 2019 Tracy Hotel and Restaurant| All Rights Reserved<br/></p>
</div>
</div>
</body>
</html>
