<?php 
session_start();
include('db.php');
include('Shopping_Cart_Function.php');

function ClearAll()
{
  unset($_SESSION['ShoppingCart_Function']);
  echo "<script>window.location='Bookinglist.php'</script>";
}

function Remove($id)
{
  $index=IndexOf($id);
  unset($_SESSION['ShoppingCart_Function'][$index]);
  echo "<script>window.location='Bookinglist.php'</script>";
}

if(isset($_GET['action'])) 
{
  $action=$_GET['action'];

  if($action==="Add") 
  {
    $id=$_GET['id'];
    $BuyQuantity=$_GET['txtBuyQty'];
    AddShoppingCart($id,$BuyQuantity);
  }
  elseif($action==="Remove") 
  {
    $id=$_GET['id'];
    Remove($id);
  }
  elseif($action==="Clear") 
  {
    ClearAll();
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to TRACY HOTEL</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/favicon.png" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<script src="js/jquery.quicksand.js" type="text/javascript"></script>
<script src="js/jquery.easing.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
</head>
<style>
strong
{
  margin-left: 700px;
} 

h1
{
  margin-left: 700px;
}


input[name=btnContinue]
{
    background: #FFFF6C;
    font-weight: bold;
    width:103px;
    height:40px;
    border-color:white;
    border-radius:6px;
}
</style>

<body>
<div id="wrapper">
  <div id="header">
    <a href="index.php"><img src="images/logo_transparent.png" class="logo" alt="TRACY HOTEL" /></a>
        <ul id="mainnav">
      <li><a href="index.php">Home</a></li>
      <li><a href="Bookinglist.php">My Booking</a></li>
      <li><a href="dining.php">Dining</a></li>
      <li><a href="facilities.php">Facilities</a></li>
      <li><a href="rooms.php">Rooms</a></li>
      <li><a href="conference.php">Conference</a></li>
      <li><a href="contact.php">Contact Us</a></li>
      </ul>
  </div>
    <div id="content">
      <div id="gallerycontainer">
      <ul class="portfolio-area">
        <br><br><br><br>
            <div>
            <div class="home-portfolio-text">
        <h2 class="post-title-portfolio"></a></h2>
        
        <form>
          <?php  
          if(!isset($_SESSION['ShoppingCart_Function'])) 
          {
            echo "<p>Booking List is Empty!</p>";
             exit();
          }
          ?>
        <fieldset>
          <table cellpadding="8px" border="2">
          <tr>
            <th>Image</th>
            <th>Type</th>
            <th>Description</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Sub-Total</th>
            <th>Action</th>
           </tr> 
          <?php  
            $count=count($_SESSION['ShoppingCart_Function']);
            for($i=0;$i<$count;$i++) 
            { 
              $id=$_SESSION['ShoppingCart_Function'][$i]['id'];  
              $img=$_SESSION['ShoppingCart_Function'][$i]['img'];

              echo "<tr>";
              echo "<td><img src='$img' width='240' height='170'/></td>";
              echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['name'] ."</td>";
              echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['description']."</td>";
              echo "<td>$" . $_SESSION['ShoppingCart_Function'][$i]['price']."</td>";
              echo "<td>" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] ." pcs</td>";

              echo "<td>$" . $_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'] * $_SESSION['ShoppingCart_Function'][$i]['price'] ."</td>";
               
              echo "<td><a href='Bookinglist.php?action=Remove&id=$id'>Remove</a></td>";
              echo "</tr>";
            }
            ?>
          </table>
          <hr><hr>          
          <table>
          <tr>
            <td>Total:</td>
            <td>$<?php echo CalculateTotalAmount() ?></b></td>
             <td><a href="Confirm.php" style="margin-left:400px"><input type="button" name="btnContinue" value="Continue"></td>
          </tr>              
          </table>
        </fieldset>
      </form>
        <div class="column-clear"></div>
          </div>
            </ul>
      <div class="clearfix"></div>
        </div>
    </div>
    
<div id="footer">
  <h4>16 &bull; U KYWE HOE STREET, KYIMYINDAING, YANGON, MYANMAR  </a></h4>
  <p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Hotel guest check-ins available daily 7-12 PM &nbsp;&nbsp;&bull;&nbsp;&nbsp;Serving Dinner Tuesday Evenings 4-10 PM</p>
  <img src="images/logo.png" alt="TRACY HOTEL"/></a>
  <p>&copy; Copyright 2019  Tracy Hotel and Restaurant| All Rights Reserved <br /></p>
</div>
</div>
</body>
</html>
