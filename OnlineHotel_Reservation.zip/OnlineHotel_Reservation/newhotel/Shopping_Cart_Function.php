<?php  
function AddShoppingCart($id,$BuyQuantity)
{
	$query="SELECT * FROM internet_shop WHERE id='$id'";
	$result=mysql_query($query);
	$count=mysql_num_rows($result);

	if($count < 1) 
	{
		echo "<p>No Booking Infomation found.</p>";
		exit();
	}

	$rows=mysql_fetch_array($result);
	$id=$rows['id'];
	$name=$rows['name'];
	$description=$rows['description'];
	$img=$rows['img'];
	$price=$rows['price'];
	$quantity=$rows['quantity'];

	if($BuyQuantity < 1)
	{
		echo "<script>window.alert('Buying Quantity cannot be Zero (0).')</script>";
		echo "<script>window.location='Bookinglist.php'</script>";
	}
	
	if($BuyQuantity > $quantity)
	{
		echo "<script>window.alert('Please enter correct quantity')</script>";
		echo "<script>window.location='Bookinglist.php'</script>";
	}

	if(isset($_SESSION['ShoppingCart_Function'])) 
	{
		$index=IndexOf($id);

		if($index == -1) 
		{
			$size=count($_SESSION['ShoppingCart_Function']);
			$_SESSION['ShoppingCart_Function'][$size]['img']=$img;
			$_SESSION['ShoppingCart_Function'][$size]['id']=$id;
			$_SESSION['ShoppingCart_Function'][$size]['name']=$name;
			$_SESSION['ShoppingCart_Function'][$size]['description']=$description;
			$_SESSION['ShoppingCart_Function'][$size]['price']=$price;
			$_SESSION['ShoppingCart_Function'][$size]['BuyQuantity']=$BuyQuantity;
			}
		else
		{
			$_SESSION['ShoppingCart_Function'][$index]['BuyQuantity']+=$BuyQuantity;
		}
	}
	else
	{
		$_SESSION['ShoppingCart_Function']=array();
		$_SESSION['ShoppingCart_Function'][0]['img']=$img;
		$_SESSION['ShoppingCart_Function'][0]['id']=$id;
		$_SESSION['ShoppingCart_Function'][0]['name']=$name;
		$_SESSION['ShoppingCart_Function'][0]['description']=$description;
		$_SESSION['ShoppingCart_Function'][0]['price']=$price;
		$_SESSION['ShoppingCart_Function'][0]['BuyQuantity']=$BuyQuantity;
	}
	//echo "<script>window.location='Shopping_Cart.php'</script>";
}

function IndexOf($id)
{
	if(!isset($_SESSION['ShoppingCart_Function'])) 
	{
		return -1;
	}

	$count=count($_SESSION['ShoppingCart_Function']);

	if ($count < 1) 
	{
		return -1;
	}

	for ($i=0;$i<$count;$i++) 
	{ 
		if($_SESSION['ShoppingCart_Function'][$i]['id'] == $id) 
		{
			return $i;
		}
	}
	return -1;
}

function CalculateTotalAmount()
{
	$TotalAmount=0;

	$count=count($_SESSION['ShoppingCart_Function']);

	for($i=0;$i<$count;$i++) 
	{ 
		$price=$_SESSION['ShoppingCart_Function'][$i]['price'];
		$quantity=$_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'];

		$TotalAmount=$TotalAmount+($price * $quantity);
	}

	return $TotalAmount;
}

function CalculateTotalQuantity()
{
	$TotalQuantity=0;

	$count=count($_SESSION['ShoppingCart_Function']);

	for($i=0;$i<$count;$i++) 
	{ 
		$quantity=$_SESSION['ShoppingCart_Function'][$i]['BuyQuantity'];

		$TotalQuantity=$TotalQuantity+($quantity);
	}

	return $TotalQuantity;
}
